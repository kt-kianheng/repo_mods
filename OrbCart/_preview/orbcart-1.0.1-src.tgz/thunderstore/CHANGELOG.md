# Changelog

## 1.0.1

- The hatch is now the cart's top face: it is fitted to the basket at load time, with a solid lid that orbs rest on until the hatch opens and pulls them in.
- New inventory icon: the Pocket C.A.R.T. icon with the closed hatch on top and an orb badge in the corner (drawn from the in-game orb's materials).
- Layout settings replaced: `HatchFill`, `HatchOffset`, `HatchStretch` (old `BoxScale` / `BoxHeight` are no longer used).

## 1.0.0

- Initial release: Orb C.A.R.T. with orb-only hatch, fill-percentage screen and configurable capacity (default $100,000).
- Built against R.E.P.O. v0.5.0 and REPOLib 4.3.0.
