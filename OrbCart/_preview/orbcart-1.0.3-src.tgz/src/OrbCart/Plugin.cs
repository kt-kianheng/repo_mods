using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace OrbCart
{
    /// <summary>
    /// Orb C.A.R.T. — a pocketable cart with a Hauler-style hatch that only accepts enemy orbs,
    /// plus a fill-percentage readout on its handle screen.
    /// The cart is assembled at startup from the game's own Pocket C.A.R.T. and Hauler prefabs,
    /// so no AssetBundle or Unity project is needed.
    /// </summary>
    [BepInPlugin(Guid, Name, Version)]
    [BepInDependency(REPOLib.MyPluginInfo.PLUGIN_GUID, BepInDependency.DependencyFlags.HardDependency)]
    public class Plugin : BaseUnityPlugin
    {
        public const string Guid = "kianheng.OrbCart";
        public const string Name = "OrbCart";
        public const string Version = "1.0.3";

        internal static Plugin Instance { get; private set; }
        internal static ManualLogSource Log { get; private set; }

        // General
        internal static ConfigEntry<float> Capacity;
        // Shop
        internal static ConfigEntry<float> PriceMultiplier;
        // Visuals
        internal static ConfigEntry<bool> TintCart;
        internal static ConfigEntry<Color> TintColor;
        internal static ConfigEntry<bool> Decals;
        // Layout (fine-tuning the hatch, which forms the cart's top face)
        internal static ConfigEntry<float> HatchFill;
        internal static ConfigEntry<float> HatchOffset;
        internal static ConfigEntry<bool> HatchStretch;

        private void Awake()
        {
            Instance = this;
            Log = Logger;
            BindConfig();

            new Harmony(Guid).PatchAll(typeof(Plugin).Assembly);

            // REPOLib requires network prefabs and items to be registered from Awake.
            GameObject prefab = OrbCartBuilder.Build();
            if (prefab == null)
            {
                Log.LogError("Orb C.A.R.T. could not be built; the item will not be available.");
                return;
            }

            ItemAttributes attributes = prefab.GetComponent<ItemAttributes>();
            PrefabRef registered = REPOLib.Modules.Items.RegisterItem(attributes);
            if (registered == null)
                Log.LogError("REPOLib refused to register the Orb C.A.R.T.");
            else
                Log.LogInfo($"{Name} {Version} loaded. Orb C.A.R.T. registered (capacity ${Capacity.Value:N0}).");
        }

        private void BindConfig()
        {
            Capacity = Config.Bind("General", "Capacity", 100000f,
                new ConfigDescription(
                    "Total orb value (in $) the Orb C.A.R.T. holds before it is full. The screen shows stored value as a percentage of this. " +
                    "The host's value is used and synced to everyone; it applies to carts spawned after the change.",
                    new AcceptableValueRange<float>(1000f, 10000000f)));

            PriceMultiplier = Config.Bind("Shop", "PriceMultiplier", 1.5f,
                new ConfigDescription("Shop price relative to the vanilla Pocket C.A.R.T. Requires a restart.",
                    new AcceptableValueRange<float>(0.1f, 20f)));

            TintCart = Config.Bind("Visuals", "TintCart", true,
                "Tint the cart body so it's easy to tell apart from a normal Pocket C.A.R.T. Requires a restart.");
            TintColor = Config.Bind("Visuals", "TintColor", new Color(0.72f, 0.55f, 1f, 1f),
                "Tint colour for the cart body. Requires a restart.");
            Decals = Config.Bind("Visuals", "OrbDecals", true,
                "Put the orb emblem on the cart's sides and front. Requires a restart.");

            HatchFill = Config.Bind("Layout", "HatchFill", 0.97f,
                new ConfigDescription("How much of the basket opening the hatch covers (1 = edge to edge). Requires a restart (all players should match).",
                    new AcceptableValueRange<float>(0.5f, 1.1f)));
            HatchOffset = Config.Bind("Layout", "HatchOffset", 0f,
                new ConfigDescription("Moves the hatch up (+) or down (-) from the basket rim, in metres. Requires a restart (all players should match).",
                    new AcceptableValueRange<float>(-0.3f, 0.2f)));
            HatchStretch = Config.Bind("Layout", "HatchStretch", true,
                "Stretch the hatch to the basket's exact width and depth. Turn off to keep the Hauler hatch's proportions. Requires a restart.");
        }
    }
}
