# Orb C.A.R.T.

A Pocket C.A.R.T.-sized cart built for enemy orbs.

- **Pocketable** – same size as the Pocket C.A.R.T. and stores in your inventory the same way.
- **Orb hatch** – the cart's top is a Hauler-style hatch. Drop an orb on it and the hatch opens and pulls it inside, safe from breaking. Anything that isn't an enemy orb is ignored.
- **Fill screen** – the screen on the handle side shows how full the cart is as a percentage, and reads **FULL** when it can't take any more.
- **Extracts like the Hauler** – push the cart into an extraction point and the stored orbs count toward the haul.

Buy it in the shop as **Orb C.A.R.T.**

## Configuration

`BepInEx/config/kianheng.OrbCart.cfg` (also editable in-game with REPOConfig).

| Section | Setting | Default | What it does |
|---|---|---|---|
| General | Capacity | 100000 | Total orb value ($) the cart holds. The screen shows stored value as a % of this. The host's value is used and synced to everyone. |
| Shop | PriceMultiplier | 1.5 | Price relative to the vanilla Pocket C.A.R.T. |
| Visuals | TintCart / TintColor | on / purple | Tints the body so it's easy to tell apart. |
| Visuals | OrbDecals | on | Orb emblem on the sides and front. |
| Layout | HatchFill / HatchOffset / HatchStretch | 0.97 / -0.15 / on | Fine-tune how the hatch fills the top of the basket. |

Capacity applies to carts spawned after a change. Shop, visual and layout settings need a restart.

## Multiplayer

Everyone needs the mod. The host decides what fits and the capacity is synced from the host.

## How it works

The cart is assembled at startup from the game's own Pocket C.A.R.T. and Hauler parts, then registered with REPOLib, so there is no asset bundle and it always matches the current game models.
