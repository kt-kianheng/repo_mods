using Photon.Pun;
using TMPro;
using UnityEngine;

namespace OrbCart
{
    /// <summary>Marker on the Orb Box's inside-box checker; Patches swaps its filter to EnemyValuable.</summary>
    public class OrbCartChecker : MonoBehaviour
    {
    }

    /// <summary>
    /// Lives on the grafted Hauler box (same GameObject as its PhotonView and ItemValuableBox).
    /// Applies the configured capacity and keeps it in sync from the host to clients.
    /// </summary>
    public class OrbCartBox : MonoBehaviour
    {
        internal ItemValuableBox Box { get; private set; }
        private PhotonView photonView;

        private void Awake()
        {
            Box = GetComponent<ItemValuableBox>();
            photonView = GetComponent<PhotonView>();
            // Read the live config so REPOConfig edits apply to newly spawned carts.
            if (Box != null) Box.valueLimit = Plugin.Capacity.Value;
        }

        private void Start()
        {
            // Only the host decides what fits; tell everyone else the host's capacity so their screens agree.
            // Buffered so players who join later (or receive the cart later) still get it.
            if (Box != null && photonView != null && SemiFunc.IsMultiplayer() && SemiFunc.IsMasterClient())
                photonView.RPC(nameof(OrbCartSetLimitRPC), RpcTarget.OthersBuffered, Box.valueLimit);
        }

        [PunRPC]
        private void OrbCartSetLimitRPC(float limit, PhotonMessageInfo info)
        {
            if (info.Sender != null && !info.Sender.IsMasterClient) return;
            if (Box != null && limit > 0f) Box.valueLimit = limit;
        }

        /// <summary>0..1 share of capacity currently stored.</summary>
        internal float Fill => Box != null && Box.valueLimit > 0f ? Mathf.Clamp01(Box.CurrentValue / Box.valueLimit) : 0f;

        internal bool IsFull => Box != null && Box.CurrentValue >= Box.valueLimit - 0.5f;
    }

    /// <summary>Drives the cart's handle-side screen (vanilla ValueScreen hardware) with the fill percentage.</summary>
    public class OrbCartScreen : MonoBehaviour
    {
        public TextMeshPro text;
        private OrbCartBox orbBox;
        private string shown;

        private void Start()
        {
            orbBox = GetComponentInChildren<OrbCartBox>(true);
        }

        private void LateUpdate()
        {
            if (text == null || orbBox == null || orbBox.Box == null) return;

            // Floor so the screen only says 100% when it is genuinely full.
            int percent = Mathf.Clamp(Mathf.FloorToInt(orbBox.Fill * 100f + 0.001f), 0, 100);
            string label = orbBox.IsFull ? "FULL" : percent + "%";

            if (label == shown && text.text == label) return;
            shown = label;
            text.text = label;
            // Same green → red ramp the Hauler screen uses for its fill preview.
            text.color = SemiFunc.ColorDifficultyGet(0f, 100f, percent);
        }
    }
}
